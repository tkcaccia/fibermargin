## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  warning = FALSE,
  message = FALSE,
  fig.width = 8,
  fig.height = 3
)
library(fibermargin)

## ----scenarios----------------------------------------------------------------
available_spatial_benchmarks()

## ----load---------------------------------------------------------------------
dlpfc <- load_spatial_benchmark("dlpfc", scenario = 1L)
names(dlpfc)

## ----one-run, eval=FALSE------------------------------------------------------
# bench <- simulate_spatial_domains(
#   n = 5000L,
#   pattern = "jagged_stripes",
#   noise = 0.20,
#   samples = 2L,
#   seed = 7L
# )
# 
# benchmark_spatial_refiners(
#   data = bench,
#   methods = list(
#     FiberMargin = refine_spatial_labels,
#     InitialOnly = function(xy, labels, ...) labels
#   ),
#   include_initial = TRUE,
#   seed = 1L
# )

