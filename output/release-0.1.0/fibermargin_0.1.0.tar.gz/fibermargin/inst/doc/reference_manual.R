## ----setup, include=FALSE-----------------------------------------------------
library(fibermargin)

## ----contract-examples--------------------------------------------------------
set.seed(8)
xy <- matrix(runif(1200), ncol = 2)
labels <- factor(ifelse(xy[, 1] < 0.5, "left", "right"))

refined_2d <- refine_spatial_labels(xy, labels, workers = 1L)
refined_flat_3d <- refine_spatial_labels(
  cbind(xy, z = 0), labels, workers = 1L
)
stopifnot(identical(refined_2d, refined_flat_3d))

volume <- simulate_volumetric_domains(
  n = 1200L, shape = "folded_layers", samples = 2L, seed = 9L
)
refined_3d <- refine_spatial_labels(
  volume$xy, volume$labels, volume$samples, workers = 2L
)
attr(refined_3d, "dimensions_used")

overlap_xy <- rbind(xy, xy)
overlap_labels <- factor(rep(as.character(labels), 2L))
specimen <- rep(c("first", "second"), each = nrow(xy))
refined_joint <- refine_spatial_labels(
  overlap_xy, overlap_labels, specimen, workers = 2L
)
attr(refined_joint, "sample_sizes")

